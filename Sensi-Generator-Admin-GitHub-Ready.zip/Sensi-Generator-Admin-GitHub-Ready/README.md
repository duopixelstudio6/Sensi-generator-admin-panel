# Sensi Generator — Professional Admin Panel

A GitHub Pages-ready admin website for Sensi Generator.

## Important architecture

GitHub Pages hosts the website. It does **not** store app activity.

Recommended final setup:

`Sensi Generator APK → secure backend → activity_events → this admin website`

This starter uses Supabase for the backend because it provides authentication, a database and realtime subscriptions from JavaScript.

## Setup

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. Replace `REPLACE_WITH_YOUR_ADMIN_EMAIL` in that SQL with your admin email before running it.
4. In Supabase, create the admin account under **Authentication → Users**.
5. Open **Project Settings → API** and copy the Project URL and Publishable key.
6. Put them into `assets/config.js`.
7. Upload this entire folder to a GitHub repository.
8. Enable GitHub Pages from **Settings → Pages** and publish from the `main` branch root.

## Security

Never put a Supabase `service_role`/secret key in this website or APK. Only use the browser-safe publishable/anon key. Keep Row Level Security enabled.

The included SQL lets only the configured admin email read activity. It intentionally does not create an unrestricted public INSERT policy. For the final APK connection, use a Supabase Edge Function so the APK cannot write arbitrary database rows directly.

## What this dashboard contains

- Secure admin login
- Overview cards
- Users
- Live Activity
- Generations
- Premium activity
- Payments area
- Settings/status
- Mobile-friendly layout
- Realtime updates

## Important

The dashboard will initially be empty. Your current APK does not automatically send its local activity logs to this online database. After the dashboard is live, the next step is to add a small secure event sender to the existing Sensi Generator source and rebuild the APK.
