// Supabase browser configuration.
// Get these from Supabase → Project Settings → API.
// NEVER paste a service_role/secret key here.
window.SENSI_CONFIG = {
  supabaseUrl: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  supabaseKey: "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE"
};
